/* This file is created by MySQLReback 2013-05-14 16:38:17 */
 /* 创建表结构`boc_address`*/
 DROP TABLE IF EXISTS`boc_address`;/* MySQLReback Separation */CREATE TABLE `boc_address` (
  `id` int(11) NOT NULL auto_increment,
  `info12` varchar(255) default NULL,
  `info11` varchar(255) default NULL,
  `info10` varchar(255) default NULL,
  `sort_id` int(11) default NULL,
  `type_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `url` varchar(255) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `show` tinyint(4) default '1',
  `timeline` int(11) default NULL,
  `postal` varchar(255) default NULL,
  `telephone` varchar(255) default NULL,
  `telephone1` varchar(255) default NULL,
  `telephone2` varchar(255) default NULL,
  `mobile` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_admin_act`*/
 DROP TABLE IF EXISTS`boc_admin_act`;/* MySQLReback Separation */CREATE TABLE `boc_admin_act` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) default NULL COMMENT '该动作的标题',
  `type_id` int(11) default NULL COMMENT '分类的编号，通常用于前台处理',
  `parent_id` int(11) default NULL COMMENT '该动作的直接父类的id',
  `depth` smallint(6) default NULL COMMENT '动作的层级深度，从0起',
  `path` varchar(255) default NULL COMMENT '层级的排列，以逗号分隔',
  `url` varchar(255) default NULL COMMENT '该动作的链接',
  `internal` tinyint(4) default NULL COMMENT '是否为站内链接？1=是，0=否',
  `ajax` tinyint(4) default '0',
  `target` varchar(32) default '_self' COMMENT '该链接的弹出方式，默认_self',
  `remark` varchar(255) default NULL COMMENT '备注说明',
  `is_use` tinyint(4) default '0' COMMENT '是否为必启栏目',
  `is_fixed` tinyint(4) default '0' COMMENT '是否固定栏目',
  `order_id` int(11) default '0',
  `timeline` int(11) default NULL COMMENT '创建该动作的时间戳',
  PRIMARY KEY  (`id`),
  KEY `path_index` (`path`)
) ENGINE=MyISAM AUTO_INCREMENT=100096 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据`boc_admin_act`*/
 INSERT INTO`boc_admin_act`VALUES('100000','后台首页','100000','0','0','100000','','1','0','_self','','1','1','100000','1330701561'),('100005','系统设置','100005','0','0','100005','','1','0','_self','','0','1','100005','1306325876'),('100006','后台首页','100006','100000','1','100000,100006','welcome','1','0','_self','','1','1','100006','1319456016'),('100007','品牌介绍','100007','0','0','100007','','1','0','','','0','0','100007','1367549253'),('100008','最新资讯','100008','0','0','100008','','1','0','_self','','0','0','100008','1367549263'),('100009','产品家族','100009','0','0','100009','','1','0','_self','','0','0','100009','1367549279'),('100010','孕期知识','100010','0','0','100010','','1','0','_self','','0','0','100010','1367549295'),('100011','专家咨询','100011','0','0','100011','','1','0','_self','','0','0','100011','1367549315'),('100012','联系我们','100012','0','0','100012','','1','0','_self','','0','0','100012','1367549326'),('100013','修改密码','100013','100000','1','100000,100013','password','1','1','_self','','1','1','100013','1330701584'),('100014','浏览前台','100014','100000','1','100000,100014','../','0','0','_blank','','1','1','100014','1330701593'),('100015','安全退出','100015','100000','1','100000,100015','login/delete','1','0','_self','','1','1','100015','1330701600'),('100094','收货地址','100094','100079','1','100079,100094','address','1','0','_self','','0','0','100094','1367835429'),('100089','资质荣誉','100089','100007','1','100007,100089','honor','1','0','_self','','0','0','100089','1367802739'),('100072','加入合智元--应聘列表','100072','100007','1','100007,100072','recruit_apply','1','0','_self','','0','0','100072','1367802655'),('100088','企业文化','100088','100007','1','100007,100088','single/index/3','1','1','_self','','0','0','100088','1367802679'),('100093','视频课程','100093','100010','1','100010,100093','video/index/2','1','0','_self','','0','0','100093','1367803010'),('100026','关键字设置','100026','100005','1','100005,100026','setup','1','1','_self','','0','1','100026','1330701668'),('100027','管理员列表','100027','100005','1','100005,100027','admin_user','1','0','_self','','0','1','100027','1304403090'),('100028','后台栏目','100028','100005','1','100005,100028','admin_menu','1','0','_self','','2','1','100028','1304403095'),('100029','数据备份','100029','100005','1','100005,100029','backup','1','1','_self','','0','1','100029','1305630120'),('100030','走进合智元','100030','100007','1','100007,100030','single/index/1','1','1','_self','','0','0','100030','1367802565'),('100031','加入合智元--说明','100031','100007','1','100007,100031','single/index/2','1','1','_self','','0','0','100031','1367802589'),('100033','加入合智元--在线招聘','100033','100007','1','100007,100033','recruit','1','0','_self','','0','0','100033','1367802628'),('100063','孕婴学堂','100063','100010','1','100010,100063','single/index/5','1','1','_self','','0','0','100063','1367802975'),('100037','活动资讯','100037','100008','1','100008,100037','news/index/1','1','0','_self','','0','0','100037','1367802772'),('100079','会员中心','100079','0','0','100079','','1','0','_self','','0','0','100076','1330999068'),('100078','友情链接','100078','100076','1','100076,100078','friend_link','1','0','_self','','0','0','100078','1330701511'),('100042','产品中心','100042','100009','1','100009,100042','product','1','0','_self','','0','0','100042','1367802858'),('100043','合智元配方','100043','100009','1','100009,100043','single/index/4','1','1','_self','','0','0','100043','1367802896'),('100044','基地介绍','100044','100009','1','100009,100044','ebook','1','0','_self','','0','0','100044','1367802929'),('100045','常见问题','100045','100011','1','100011,100045','news/index/5','1','0','_self','','0','0','100045','1367803064'),('100046','在线问答','100046','100011','1','100011,100046','question','1','0','_self','','0','0','100046','1367803099'),('100047','客户留言','100047','100011','1','100011,100047','feedback','1','0','_self','','0','0','100047','1367803144'),('100048','联系我们','100048','100012','1','100012,100048','single/index/6','1','1','_self','','0','0','100048','1367803163'),('100095','订单列表','100095','100079','1','100079,100095','order','1','0','_self','','0','0','100095','1367835444'),('100062','孕期营养杂志','100062','100010','1','100010,100062','download','1','0','_self','','0','0','100062','1367802957'),('100076','其他栏目','100076','0','0','100076','','1','0','_self','','0','0','100079','1367549407'),('100077','媒体报道','100077','100008','1','100008,100077','news/index/2','1','0','_self','','0','0','100077','1367812929'),('100080','会员列表','100080','100079','1','100079,100080','users','1','0','_self','','0','0','100080','1330999105'),('100090','视频欣赏','100090','100007','1','100007,100090','video/index/1','1','0','_self','','0','0','100090','1367802731'),('100087','首页图片切换','100087','100076','1','100076,100087','showcase','1','0','_self','','0','0','100087','1367803303');/* MySQLReback Separation */
 /* 插入数据`boc_admin_act`*/
 INSERT INTO`boc_admin_act`VALUES('100091','科研成果','100091','100008','1','100008,100091','news/index/3','1','0','_self','','0','0','100091','1367802808');/* MySQLReback Separation */
 /* 插入数据`boc_admin_act`*/
 INSERT INTO`boc_admin_act`VALUES('100092','专家资讯','100092','100008','1','100008,100092','news/index/4','1','0','_self','','0','0','100092','1367812935');/* MySQLReback Separation */
 /* 创建表结构`boc_admin_ban`*/
 DROP TABLE IF EXISTS`boc_admin_ban`;/* MySQLReback Separation */CREATE TABLE `boc_admin_ban` (
  `ip` varchar(50) NOT NULL,
  `ban` tinyint(4) default '0' COMMENT '是否禁止登录',
  `reason` varchar(100) default NULL COMMENT '被禁止理由',
  `attempt` int(11) default '0' COMMENT '输入错误次数',
  `timeline` int(11) default '0' COMMENT '解封时间戳',
  `timelast` int(11) default '0' COMMENT '上次输入的时间戳',
  PRIMARY KEY  (`ip`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据`boc_admin_ban`*/
 INSERT INTO`boc_admin_ban`VALUES('125.120.67.206','1','连续输入帐号或密码错误','5','1330703865','1330702064');/* MySQLReback Separation */
 /* 创建表结构`boc_admin_user`*/
 DROP TABLE IF EXISTS`boc_admin_user`;/* MySQLReback Separation */CREATE TABLE `boc_admin_user` (
  `account` varchar(64) NOT NULL,
  `password` varchar(32) default NULL,
  `role` varchar(64) default NULL,
  `auth` text COMMENT '拥有的权限',
  `shortcut` text COMMENT '我的链接',
  `title` varchar(100) default NULL COMMENT '该帐号的名称',
  `email` varchar(255) default NULL,
  `qq` varchar(255) default NULL,
  `msn` varchar(255) default NULL,
  `tel` varchar(100) default NULL,
  `timeline` int(11) default NULL COMMENT '该帐号的创建时间戳',
  `create_ip` varchar(64) default NULL,
  `login_ip` varchar(64) default NULL,
  `login_count` int(11) default NULL COMMENT '登录次数',
  `timelast` int(11) default NULL,
  PRIMARY KEY  (`account`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据`boc_admin_user`*/
 INSERT INTO`boc_admin_user`VALUES('bocadmin','29d18418d5d1a6c10e5e57b3e09b24b3','admin','','','','','','','','0','','115.193.191.49','56','1351581769'),('webadmin','2a232a5b14c631b2f37034aa2130f538','admin','','','','','','','','1328957568','115.192.185.88','127.0.0.1','124','1368520685'),('test','098f6bcd4621d373cade4e832627b4f6','user','a:5:{i:100006;a:4:{s:5:\"index\";i:1;s:4:\"post\";i:1;s:3:\"put\";i:1;s:6:\"delete\";i:1;}i:100013;a:4:{s:5:\"index\";i:1;s:4:\"post\";i:1;s:3:\"put\";i:1;s:6:\"delete\";i:1;}i:100014;a:4:{s:5:\"index\";i:1;s:4:\"post\";i:1;s:3:\"put\";i:1;s:6:\"delete\";i:1;}i:100015;a:4:{s:5:\"index\";i:1;s:4:\"post\";i:1;s:3:\"put\";i:1;s:6:\"delete\";i:1;}i:100030;a:2:{s:5:\"index\";i:1;s:6:\"delete\";i:1;}}','','','','','','','1361873857','115.238.95.194','115.238.95.194','1','1361873869');/* MySQLReback Separation */
 /* 创建表结构`boc_ads`*/
 DROP TABLE IF EXISTS`boc_ads`;/* MySQLReback Separation */CREATE TABLE `boc_ads` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `class_id` int(11) default NULL,
  `ad_type` tinyint(4) default NULL COMMENT '广告类型：1代码，2图片，3文字，4flash',
  `title` varchar(255) default NULL,
  `content` text,
  `url` varchar(255) default NULL,
  `file` varchar(255) default NULL,
  `width` smallint(6) default NULL,
  `height` smallint(6) default NULL,
  `timeline` int(11) default NULL,
  `start_timeline` int(11) default NULL,
  `end_timeline` int(11) default NULL,
  `remark` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_attachment`*/
 DROP TABLE IF EXISTS`boc_attachment`;/* MySQLReback Separation */CREATE TABLE `boc_attachment` (
  `id` int(11) NOT NULL auto_increment,
  `url` varchar(255) default NULL,
  `state` tinyint(4) default '1' COMMENT '1=临时保存，2=使用中，3=已废弃',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_config`*/
 DROP TABLE IF EXISTS`boc_config`;/* MySQLReback Separation */CREATE TABLE `boc_config` (
  `id` int(11) NOT NULL auto_increment,
  `category` varchar(100) default '' COMMENT '配置分类，方便批量读取',
  `config` varchar(100) default '',
  `value` text,
  PRIMARY KEY  (`id`),
  KEY `config_index` (`config`,`category`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据`boc_config`*/
 INSERT INTO`boc_config`VALUES('1','password_reset','delay','60'),('2','password_reset','email','tags@126.com'),('3','password_reset','smtp_user','tags@126.com'),('4','password_reset','smtp_pass','123456'),('5','password_reset','protocol','smtp'),('6','password_reset','smtp_host','smtp.126.com'),('7','password_reset','smtp_timeout','5'),('8','password_reset','charset','GBK'),('9','password_reset','useragent','126.com'),('10','password_reset','mailtype','html'),('11','password_reset','newline','\\r\\n'),('12','password_reset','crlf','\\r\\n'),('13','password_reset','caption','标签网'),('14','password_reset','smtp_port','25'),('15','site','stat_url',''),('16','site','click_random','10'),('18','site','btm_copyright','Copyright 2011 标签网 Tag Nets All Rights Reserved.'),('19','site','btm_tel','0571-12345678'),('20','site','btm_email','tags@gmail.com'),('21','site','btm_company','标签网 &copy;'),('22','site','btm_icp','浙ICP证10000007号'),('23','site','title','杭州天龙孕婴健康产品有限公司'),('24','site','keywords','杭州天龙孕婴健康产品有限公司'),('25','site','description','杭州天龙孕婴健康产品有限公司'),('26','cache','homepage','10'),('27','cache','column','9'),('28','cache','search','9'),('29','cache','union','9'),('30','cache','event','9'),('31','cache','news','9'),('32','admin','backup','1367574515'),('33','site','code',''),('34','site','icpcode','浙ICP备05044604号'),('35','site','weburl','');/* MySQLReback Separation */
 /* 创建表结构`boc_download`*/
 DROP TABLE IF EXISTS`boc_download`;/* MySQLReback Separation */CREATE TABLE `boc_download` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL COMMENT '排序编号',
  `type_id` int(11) default NULL COMMENT '类型',
  `title` varchar(255) default NULL COMMENT '标题',
  `intro` varchar(1000) default NULL COMMENT '简介',
  `content` mediumtext COMMENT '详细内容',
  `show` tinyint(11) default '1' COMMENT '是否显示',
  `recommend` tinyint(11) default '0' COMMENT '是否推荐',
  `timeline` int(11) default NULL COMMENT '发布时间',
  `photo` varchar(255) default NULL COMMENT '图片',
  `thumb` varchar(255) default NULL COMMENT '缩略图',
  `file` varchar(255) default NULL COMMENT '上传文件',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_ebook`*/
 DROP TABLE IF EXISTS`boc_ebook`;/* MySQLReback Separation */CREATE TABLE `boc_ebook` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `type_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `intro` varchar(1000) default NULL,
  `content` mediumtext,
  `show` tinyint(11) default '1',
  `recommend` tinyint(11) default '0',
  `timeline` int(11) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `file` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_ebook_type`*/
 DROP TABLE IF EXISTS`boc_ebook_type`;/* MySQLReback Separation */CREATE TABLE `boc_ebook_type` (
  `id` int(11) NOT NULL auto_increment,
  `type_id` int(11) default '1',
  `parent_id` int(11) default NULL,
  `depth` int(11) default '0',
  `path` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `intro` varchar(1000) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `order_id` int(11) default '0',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `path_index` (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_email_delay`*/
 DROP TABLE IF EXISTS`boc_email_delay`;/* MySQLReback Separation */CREATE TABLE `boc_email_delay` (
  `id` int(11) NOT NULL auto_increment,
  `event` varchar(100) default NULL,
  `my_id` int(11) default NULL,
  `ip` varchar(50) default NULL,
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `event_index` (`event`,`my_id`,`timeline`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_epage`*/
 DROP TABLE IF EXISTS`boc_epage`;/* MySQLReback Separation */CREATE TABLE `boc_epage` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `book_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `show` int(11) default '1',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_event`*/
 DROP TABLE IF EXISTS`boc_event`;/* MySQLReback Separation */CREATE TABLE `boc_event` (
  `id` int(11) NOT NULL auto_increment COMMENT '唯一编号',
  `sort_id` int(11) default '1' COMMENT '排序编号',
  `type_id` int(11) default NULL COMMENT '类型',
  `title` varchar(255) default NULL COMMENT '标题',
  `intro` varchar(1000) default NULL COMMENT '简介',
  `content` mediumtext COMMENT '内容',
  `timeline` int(11) default NULL COMMENT '发布/修改时间',
  `expire` int(11) default NULL COMMENT '公告过期时间',
  `author` varchar(50) default NULL COMMENT '消息作者',
  `author_url` varchar(255) default NULL COMMENT '作者链接',
  `source` varchar(50) default NULL COMMENT '消息来源',
  `source_url` varchar(255) default NULL COMMENT '来源链接',
  `click` int(11) default '0' COMMENT '浏览次数',
  `show` tinyint(4) default '1' COMMENT '显隐状态',
  `recommend` tinyint(4) default '0' COMMENT '推荐到分类门户的页面显示',
  `color` tinyint(4) default '0' COMMENT '突显状态/颜色',
  `audit` tinyint(4) default NULL COMMENT '审核状态',
  `photo` varchar(255) default NULL COMMENT '相关图片',
  `thumb` varchar(255) default NULL COMMENT '图片缩略图',
  `file` varchar(255) default NULL COMMENT '相关文件',
  `ex1` varchar(255) default '' COMMENT '其他标签（预留）',
  `ex2` varchar(255) default '',
  `ex3` varchar(255) default '',
  `ex4` varchar(255) default '',
  `ex5` varchar(255) default '',
  `ex6` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_event_banner`*/
 DROP TABLE IF EXISTS`boc_event_banner`;/* MySQLReback Separation */CREATE TABLE `boc_event_banner` (
  `id` int(11) NOT NULL auto_increment,
  `type_id` int(11) default NULL,
  `sort_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `content` mediumtext,
  `url` varchar(255) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `recommend` tinyint(4) default NULL,
  `show` tinyint(4) default '1',
  `click` int(11) default NULL,
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_event_type`*/
 DROP TABLE IF EXISTS`boc_event_type`;/* MySQLReback Separation */CREATE TABLE `boc_event_type` (
  `id` int(11) NOT NULL auto_increment,
  `type_id` int(11) default '1',
  `parent_id` int(11) default NULL,
  `depth` int(11) default '0',
  `path` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `intro` varchar(1000) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `order_id` int(11) default '0',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `path_index` (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_feedback`*/
 DROP TABLE IF EXISTS`boc_feedback`;/* MySQLReback Separation */CREATE TABLE `boc_feedback` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `type_id` int(11) default NULL,
  `title` varchar(100) default NULL,
  `content` text,
  `answer` text,
  `username` varchar(50) default NULL,
  `phone` varchar(50) default NULL,
  `tel` varchar(50) default NULL,
  `email` varchar(100) default NULL,
  `addr` varchar(100) default NULL,
  `audit` tinyint(4) default NULL,
  `solve` tinyint(4) default '0' COMMENT '已解决？',
  `show` tinyint(4) default NULL,
  `timeline` int(11) default NULL,
  `answer_time` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_files`*/
 DROP TABLE IF EXISTS`boc_files`;/* MySQLReback Separation */CREATE TABLE `boc_files` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `type_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `url` varchar(255) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `file` varchar(255) default NULL,
  `show` tinyint(4) default '1',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_fpage`*/
 DROP TABLE IF EXISTS`boc_fpage`;/* MySQLReback Separation */CREATE TABLE `boc_fpage` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `book_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `show` int(11) default '1',
  `timeline` int(11) default NULL,
  `file` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_friend_link`*/
 DROP TABLE IF EXISTS`boc_friend_link`;/* MySQLReback Separation */CREATE TABLE `boc_friend_link` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `type_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `url` varchar(255) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `show` tinyint(4) default '1',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_honor`*/
 DROP TABLE IF EXISTS`boc_honor`;/* MySQLReback Separation */CREATE TABLE `boc_honor` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `type_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `url` varchar(255) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `show` tinyint(4) default '1',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_honor_type`*/
 DROP TABLE IF EXISTS`boc_honor_type`;/* MySQLReback Separation */CREATE TABLE `boc_honor_type` (
  `id` int(11) NOT NULL auto_increment,
  `type_id` int(11) default '1',
  `parent_id` int(11) default NULL,
  `depth` int(11) default '0',
  `path` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `intro` varchar(1000) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `order_id` int(11) default '0',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `path_index` (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_infos`*/
 DROP TABLE IF EXISTS`boc_infos`;/* MySQLReback Separation */CREATE TABLE `boc_infos` (
  `id` int(11) NOT NULL auto_increment COMMENT '唯一编号',
  `type_id` int(11) default NULL COMMENT '类型',
  `title` varchar(255) default NULL COMMENT '标题',
  `intro` varchar(1000) default NULL COMMENT '简介',
  `photo` varchar(255) default NULL COMMENT '图片',
  `thumb` varchar(255) default NULL COMMENT '缩略图',
  `content` text,
  `timeline` int(11) default NULL COMMENT '发布/修改时间',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_network`*/
 DROP TABLE IF EXISTS`boc_network`;/* MySQLReback Separation */CREATE TABLE `boc_network` (
  `id` int(11) NOT NULL auto_increment,
  `type_id` int(11) default NULL,
  `city_id` int(11) default NULL,
  `sort_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `intro` varchar(1000) default NULL,
  `content` mediumtext,
  `tel` varchar(100) default NULL,
  `fax` varchar(100) default NULL,
  `addr` varchar(100) default NULL,
  `url` varchar(255) default NULL,
  `show` tinyint(4) default NULL,
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_network_city`*/
 DROP TABLE IF EXISTS`boc_network_city`;/* MySQLReback Separation */CREATE TABLE `boc_network_city` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(100) default NULL,
  `entitle` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据`boc_network_city`*/
 INSERT INTO`boc_network_city`VALUES('1','北京市','BeiJing'),('2','天津市','Tianjin'),('3','河北省','Hebei'),('4','山西省','Shanxi'),('5','辽宁省','Liaoning'),('6','吉林省','Jilin'),('7','上海市','Shanghai'),('8','江苏省','Jiangsu'),('9','浙江省','Zhejiang'),('10','安徽省','Anhui'),('11','福建省','Fujian'),('12','江西省','Jiangxi'),('13','山东省','Shandong'),('14','河南省','Henan'),('15','内蒙古','Neimenggu'),('16','黑龙江省','Heilongjiang'),('17','湖北省','Hubei'),('18','湖南省','Hunan'),('19','广东省','Guangdong'),('20','广西省','Guangxi'),('21','海南省','Hainan'),('22','四川省','Sichuan'),('23','重庆市','Chongqing'),('24','台湾省','Taiwan'),('25','贵州省','Guizhou'),('26','云南省','Yunnan'),('27','西藏','Xizang'),('28','陕西省','Shanxi'),('29','甘肃省','Gansu'),('30','青海省','Qinghai'),('31','宁夏','Ningxia'),('32','新疆','Xinjiang'),('33','香港','xianggang'),('34','澳门','aomen'),('35','钓鱼岛','Diaoyudao');/* MySQLReback Separation */
 /* 创建表结构`boc_news`*/
 DROP TABLE IF EXISTS`boc_news`;/* MySQLReback Separation */CREATE TABLE `boc_news` (
  `id` int(11) NOT NULL auto_increment COMMENT '唯一编号',
  `sort_id` int(11) default '1' COMMENT '排序编号',
  `type_id` int(11) default NULL COMMENT '类型',
  `title` varchar(255) default NULL COMMENT '标题',
  `intro` varchar(1000) default NULL COMMENT '简介',
  `tag` varchar(255) default NULL COMMENT '标签',
  `content` mediumtext COMMENT '内容',
  `timeline` int(11) default NULL COMMENT '发布/修改时间',
  `expire` int(11) default NULL COMMENT '公告过期时间',
  `author` varchar(50) default NULL COMMENT '消息作者',
  `author_url` varchar(255) default NULL COMMENT '作者链接',
  `source` varchar(50) default NULL COMMENT '消息来源',
  `source_url` varchar(255) default NULL COMMENT '来源链接',
  `click` int(11) default '0' COMMENT '浏览次数',
  `show` tinyint(4) default '1' COMMENT '显隐状态',
  `recommend` tinyint(4) default '0' COMMENT '推荐到分类门户的页面显示',
  `homepage` tinyint(4) default '0' COMMENT '推荐到首页显示',
  `recommend_photo` tinyint(4) default '0' COMMENT '作为分类栏目的跑马灯图片新闻',
  `homepage_photo` tinyint(4) default '0' COMMENT '作为首页的跑马灯图片新闻',
  `color` tinyint(4) default '0' COMMENT '突显状态/颜色',
  `photo` varchar(255) default NULL COMMENT '相关图片',
  `thumb` varchar(255) default NULL COMMENT '图片缩略图',
  `file` varchar(255) default NULL COMMENT '相关文件',
  `ex1` varchar(255) default '' COMMENT '其他标签（预留）',
  `ex2` varchar(255) default '',
  `ex3` varchar(255) default '',
  `ex4` varchar(255) default '',
  `ex5` varchar(255) default '',
  `ex6` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_news_tag`*/
 DROP TABLE IF EXISTS`boc_news_tag`;/* MySQLReback Separation */CREATE TABLE `boc_news_tag` (
  `id` int(11) NOT NULL auto_increment,
  `tag` varchar(50) default NULL,
  `records` int(11) default '0' COMMENT '有该标签的商闻数量，用于检索tag_index表',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_news_tag_index`*/
 DROP TABLE IF EXISTS`boc_news_tag_index`;/* MySQLReback Separation */CREATE TABLE `boc_news_tag_index` (
  `id` int(11) NOT NULL auto_increment,
  `tag_id` int(11) default NULL,
  `record_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `record_index` (`id`,`tag_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_news_type`*/
 DROP TABLE IF EXISTS`boc_news_type`;/* MySQLReback Separation */CREATE TABLE `boc_news_type` (
  `id` int(11) NOT NULL auto_increment,
  `type_id` int(11) default '1',
  `parent_id` int(11) default NULL,
  `depth` int(11) default '0',
  `path` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `intro` varchar(1000) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `order_id` int(11) default '0',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `path_index` (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_order`*/
 DROP TABLE IF EXISTS`boc_order`;/* MySQLReback Separation */CREATE TABLE `boc_order` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `type_id` int(11) default NULL,
  `order_id` varchar(255) default NULL,
  `product_id` text,
  `product_title` varchar(255) default NULL,
  `sex` varchar(55) default NULL,
  `title` varchar(100) default NULL,
  `name` text,
  `content` text,
  `mobile` varchar(255) default NULL,
  `postal` varchar(255) default NULL,
  `price` varchar(255) default NULL,
  `note` text,
  `size` varchar(255) default NULL,
  `num` int(11) default NULL,
  `user_id` int(11) default NULL,
  `answer` text,
  `username` varchar(50) default NULL,
  `qty` text,
  `tel` varchar(50) default NULL,
  `email` varchar(100) default NULL,
  `addr` varchar(100) default NULL,
  `audit` tinyint(4) default NULL,
  `pic` text,
  `solve` tinyint(4) default '0' COMMENT '已解决？',
  `show` tinyint(4) default NULL,
  `timeline` int(11) default NULL,
  `answer_time` int(11) default NULL,
  `order` text,
  `pay_status` int(4) default NULL,
  `trade_no` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_partner`*/
 DROP TABLE IF EXISTS`boc_partner`;/* MySQLReback Separation */CREATE TABLE `boc_partner` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `type_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `url` varchar(255) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `show` tinyint(4) default '1',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_partner_type`*/
 DROP TABLE IF EXISTS`boc_partner_type`;/* MySQLReback Separation */CREATE TABLE `boc_partner_type` (
  `id` int(11) NOT NULL auto_increment,
  `type_id` int(11) default '1',
  `parent_id` int(11) default NULL,
  `depth` int(11) default '0',
  `path` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `intro` varchar(1000) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `order_id` int(11) default '0',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `path_index` (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_picture`*/
 DROP TABLE IF EXISTS`boc_picture`;/* MySQLReback Separation */CREATE TABLE `boc_picture` (
  `id` int(11) NOT NULL auto_increment COMMENT '唯一编号',
  `type_id` int(11) default NULL COMMENT '类型',
  `title` varchar(255) default NULL COMMENT '标题',
  `intro` varchar(1000) default NULL COMMENT '简介',
  `photo` varchar(255) default NULL COMMENT '图片',
  `thumb` varchar(255) default NULL COMMENT '缩略图',
  `timeline` int(11) default NULL COMMENT '发布/修改时间',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_product`*/
 DROP TABLE IF EXISTS`boc_product`;/* MySQLReback Separation */CREATE TABLE `boc_product` (
  `id` int(11) NOT NULL auto_increment,
  `type_id` int(11) default NULL,
  `sort_id` int(11) default '1' COMMENT '排序编号',
  `title` varchar(255) default NULL,
  `intro` varchar(1000) default NULL,
  `content` mediumtext,
  `type1` int(11) default NULL COMMENT '外观尺寸mm',
  `type2` int(11) default NULL,
  `type3` int(11) default NULL,
  `type4` int(11) default NULL,
  `type5` int(11) default NULL,
  `type6` int(11) default NULL,
  `pic1` varchar(255) default NULL,
  `pic2` varchar(255) default NULL,
  `pic3` varchar(255) default NULL,
  `pic4` varchar(255) default NULL,
  `pic5` varchar(255) default NULL,
  `pic6` varchar(255) default NULL,
  `thumb1` varchar(255) default NULL,
  `thumb2` varchar(255) default NULL,
  `thumb3` varchar(255) default NULL,
  `thumb4` varchar(255) default NULL,
  `thumb5` varchar(255) default NULL,
  `thumb6` varchar(255) default NULL,
  `file1` varchar(255) default NULL,
  `file2` varchar(255) default NULL,
  `file3` varchar(255) default NULL,
  `file4` varchar(255) default NULL,
  `file5` varchar(255) default NULL,
  `file6` varchar(255) default NULL,
  `tab1` varchar(100) default NULL,
  `tab2` varchar(100) default NULL,
  `tab3` varchar(100) default NULL,
  `tab4` varchar(100) default NULL,
  `tab5` varchar(100) default NULL,
  `tab6` varchar(100) default NULL,
  `desc1` mediumtext,
  `desc2` mediumtext,
  `desc3` mediumtext,
  `desc4` mediumtext,
  `desc5` mediumtext,
  `desc6` mediumtext,
  `tag` varchar(255) default NULL COMMENT '多个标签字符，逗号分隔',
  `attr` varchar(255) default NULL COMMENT '多种属性id，逗号分隔',
  `show` tinyint(1) default '1',
  `recommend` tinyint(4) default '0',
  `click` int(11) default '0',
  `timeline` int(11) default NULL,
  `ex1` varchar(255) default NULL,
  `ex2` varchar(255) default NULL,
  `ex3` varchar(255) default NULL,
  `ex4` varchar(255) default NULL,
  `ex5` varchar(255) default NULL,
  `ex6` varchar(255) default NULL,
  `huohao` varchar(100) default NULL,
  `guige` varchar(100) default NULL,
  `gonglv` varchar(100) default NULL,
  `liuming` varchar(100) default NULL,
  `sewen` varchar(100) default NULL,
  `dianya` varchar(100) default NULL,
  `dianliu` varchar(100) default NULL,
  `shouming` varchar(100) default NULL,
  `zhengdengchicun` varchar(100) default NULL,
  `dengtou` varchar(100) default NULL,
  `kandela` varchar(100) default NULL,
  `faguangjiaodu` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_product_type`*/
 DROP TABLE IF EXISTS`boc_product_type`;/* MySQLReback Separation */CREATE TABLE `boc_product_type` (
  `id` int(11) NOT NULL auto_increment,
  `type_id` int(11) default '1',
  `parent_id` int(11) default NULL,
  `depth` int(11) default '0',
  `path` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `intro` varchar(1000) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `order_id` int(11) default '0',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `path_index` (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_province_city`*/
 DROP TABLE IF EXISTS`boc_province_city`;/* MySQLReback Separation */CREATE TABLE `boc_province_city` (
  `id` int(11) NOT NULL auto_increment,
  `province_id` int(11) NOT NULL,
  `title` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=384 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据`boc_province_city`*/
 INSERT INTO`boc_province_city`VALUES('1','1','北京'),('2','2','天津'),('3','3','石家庄'),('4','3','保定'),('5','3','沧州'),('6','3','承德'),('7','3','邯郸'),('8','3','衡水'),('9','3','廊坊'),('10','3','秦皇岛'),('11','3','唐山'),('12','3','邢台'),('13','3','张家口'),('14','4','太原'),('15','4','长治'),('16','4','大同'),('17','4','晋城'),('18','4','晋中'),('19','4','临汾'),('20','4','吕梁'),('21','4','朔州'),('22','4','忻州'),('23','4','阳泉'),('24','4','运城'),('25','5','沈阳'),('26','5','大连'),('27','5','鞍山'),('28','5','本溪'),('29','5','朝阳'),('30','5','丹东'),('31','5','抚顺'),('32','5','阜新'),('33','5','葫芦岛'),('34','5','锦州'),('35','5','辽阳'),('36','5','盘锦'),('37','5','铁岭'),('38','5','营口'),('39','6','长春'),('40','6','吉林'),('41','6','白城'),('42','6','白山'),('43','6','辽源'),('44','6','四平'),('45','6','松原'),('46','6','通化'),('47','6','延边朝鲜族自治州'),('48','7','上海'),('49','8','南京'),('50','8','常州'),('51','8','淮安'),('52','8','连云港'),('53','8','南通'),('54','8','苏州'),('55','8','宿迁'),('56','8','泰州'),('57','8','无锡'),('58','8','徐州'),('59','8','盐城'),('60','8','扬州'),('61','8','镇江'),('62','9','杭州'),('63','9','湖州'),('64','9','嘉兴'),('65','9','金华'),('66','9','丽水'),('67','9','宁波'),('68','9','绍兴'),('69','9','台州'),('70','9','温州'),('71','9','舟山'),('72','9','衢州'),('73','10','合肥'),('74','10','安庆'),('75','10','蚌埠'),('76','10','巢湖'),('77','10','池州'),('78','10','滁州'),('79','10','阜阳'),('80','10','淮北'),('81','10','淮南'),('82','10','黄山'),('83','10','六安'),('84','10','马鞍山'),('85','10','宿州'),('86','10','铜陵'),('87','10','芜湖'),('88','10','宣城'),('89','10','亳州'),('90','11','福州'),('91','11','厦门'),('92','11','龙岩'),('93','11','南平'),('94','11','宁德'),('95','11','莆田'),('96','11','泉州'),('97','11','三明'),('98','11','漳州'),('99','12','南昌'),('100','12','抚州'),('101','12','赣州'),('102','12','吉安'),('103','12','景德镇'),('104','12','九江'),('105','12','萍乡'),('106','12','上饶'),('107','12','新余'),('108','12','宜春'),('109','12','鹰潭'),('110','13','济南'),('111','13','青岛'),('112','13','烟台'),('113','13','滨州'),('114','13','德州'),('115','13','东营'),('116','13','菏泽'),('117','13','济宁'),('118','13','莱芜'),('119','13','聊城'),('120','13','临沂'),('121','13','日照'),('122','13','泰安'),('123','13','威海'),('124','13','潍坊'),('125','13','枣庄'),('126','13','淄博'),('127','14','郑州'),('128','14','洛阳'),('129','14','开封'),('130','14','安阳'),('131','14','鹤壁'),('132','14','济源'),('133','14','焦作'),('134','14','南阳'),('135','14','平顶山'),('136','14','三门峡'),('137','14','商丘'),('138','14','新乡'),('139','14','信阳'),('140','14','许昌'),('141','14','周口'),('142','14','驻马店'),('143','14','漯河'),('144','14','濮阳'),('145','15','呼和浩特'),('146','15','包头'),('147','15','赤峰'),('148','15','鄂尔多斯'),('149','15','呼伦贝尔'),('150','15','阿拉善盟'),('151','15','巴彦淖尔盟'),('152','15','通辽'),('153','15','乌海'),('154','15','乌兰察布盟'),('155','15','锡林郭勒盟'),('156','15','兴安盟'),('157','16','哈尔滨'),('158','16','大庆'),('159','16','大兴安岭'),('160','16','鹤岗'),('161','16','黑河'),('162','16','鸡西'),('163','16','佳木斯'),('164','16','牡丹江'),('165','16','七台河'),('166','16','齐齐哈尔'),('167','16','双鸭山'),('168','16','绥化'),('169','16','伊春'),('170','17','武汉'),('171','17','鄂州'),('172','17','黄冈'),('173','17','黄石'),('174','17','荆门'),('175','17','荆州'),('176','17','潜江'),('177','17','十堰'),('178','17','随州'),('179','17','天门'),('180','17','仙桃'),('181','17','咸宁'),('182','17','襄樊'),('183','17','孝感'),('184','17','宜昌'),('185','17','恩施土家族苗族自治州'),('186','17','神农架林区'),('187','18','长沙'),('188','18','益阳'),('189','18','湘潭'),('190','18','常德'),('191','18','郴州'),('192','18','衡阳'),('193','18','怀化'),('194','18','娄底'),('195','18','邵阳'),('196','18','永州'),('197','18','岳阳'),('198','18','张家界'),('199','18','株洲'),('200','18','湘西土家族苗族自治州'),('201','19','广州'),('202','19','深圳'),('203','19','珠海'),('204','19','湛江'),('205','19','惠州'),('206','19','江门'),('207','19','潮州'),('208','19','汕头'),('209','19','东莞'),('210','19','佛山'),('211','19','河源'),('212','19','揭阳'),('213','19','茂名'),('214','19','梅州'),('215','19','清远'),('216','19','汕尾'),('217','19','韶关'),('218','19','阳江'),('219','19','云浮'),('220','19','肇庆'),('221','19','中山'),('222','20','南宁'),('223','20','桂林'),('224','20','北海'),('225','20','百色'),('226','20','崇左'),('227','20','防城港'),('228','20','贵港'),('229','20','河池'),('230','20','贺州'),('231','20','来宾'),('232','20','柳州'),('233','20','钦州'),('234','20','梧州'),('235','20','玉林'),('236','21','海口'),('237','21','三亚'),('238','21','白沙黎族自治县'),('239','21','保亭黎族苗族自治县'),('240','21','昌江黎族自治县');/* MySQLReback Separation */
 /* 插入数据`boc_province_city`*/
 INSERT INTO`boc_province_city`VALUES('241','21','澄迈县');/* MySQLReback Separation */
 /* 插入数据`boc_province_city`*/
 INSERT INTO`boc_province_city`VALUES('242','21','定安县'),('243','21','东方'),('244','21','乐东黎族自治县'),('245','21','临高县'),('246','21','陵水黎族自治县'),('247','21','琼海'),('248','21','琼中黎族苗族自治县'),('249','21','屯昌县'),('250','21','万宁'),('251','21','文昌'),('252','21','五指山'),('253','21','儋州'),('254','22','成都'),('255','22','绵阳'),('256','22','巴中'),('257','22','达州'),('258','22','德阳'),('259','22','广安'),('260','22','广元'),('261','22','乐山'),('262','22','眉山'),('263','22','南充'),('264','22','内江'),('265','22','攀枝花'),('266','22','遂宁'),('267','22','雅安'),('268','22','宜宾'),('269','22','资阳'),('270','22','自贡'),('271','22','泸州'),('272','22','甘孜藏族自治州'),('273','22','阿坝藏族羌族自治州'),('274','22','凉山彝族自治州'),('275','23','重庆'),('276','24','台北'),('277','24','高雄'),('278','24','台中'),('279','24','台南'),('280','24','新北'),('281','24','基隆'),('282','24','新竹'),('283','24','嘉义'),('284','24','桃园县'),('285','24','新竹县'),('286','24','苗栗县'),('287','24','彰化县'),('288','24','南投县'),('289','24','云林县'),('290','24','嘉义县'),('291','24','屏东县'),('292','24','宜兰县'),('293','24','花莲县'),('294','24','台东县'),('295','24','澎湖县'),('296','24','金门县'),('297','24','连江县'),('298','25','贵阳'),('299','25','六盘水'),('300','25','遵义'),('301','25','安顺'),('302','25','毕节'),('303','25','铜仁'),('304','25','黔东南苗族侗族自治州'),('305','25','黔南布依族苗族自治州'),('306','25','黔西南布依族苗族自治州'),('307','26','昆明'),('308','26','丽江'),('309','26','保山'),('310','26','楚雄彝族自治州'),('311','26','大理白族自治州'),('312','26','德宏傣族景颇族自治州'),('313','26','迪庆藏族自治州'),('314','26','红河哈尼族彝族自治州'),('315','26','临沧'),('316','26','怒江傈傈族自治州'),('317','26','曲靖'),('318','26','思茅'),('319','26','文山壮族苗族自治州'),('320','26','西双版纳傣族自治州'),('321','26','玉溪'),('322','26','昭通'),('323','27','拉萨'),('324','27','日喀则'),('325','27','阿里'),('326','27','昌都'),('327','27','林芝'),('328','27','那曲'),('329','27','山南'),('330','28','西安'),('331','28','宝鸡'),('332','28','咸阳'),('333','28','延安'),('334','28','榆林'),('335','28','安康'),('336','28','汉中'),('337','28','商洛'),('338','28','铜川'),('339','28','渭南'),('340','29','兰州'),('341','29','白银'),('342','29','定西'),('343','29','嘉峪关'),('344','29','金昌'),('345','29','酒泉'),('346','29','陇南'),('347','29','平凉'),('348','29','庆阳'),('349','29','天水'),('350','29','武威'),('351','29','张掖'),('352','29','临夏回族自治州'),('353','29','甘南藏族自治州'),('354','30','西宁'),('355','30','果洛藏族自治州'),('356','30','海北藏族自治州'),('357','30','海东'),('358','30','海南藏族自治州'),('359','30','海西蒙古族藏族自治州'),('360','30','黄南藏族自治州'),('361','30','玉树藏族自治州'),('362','31','银川'),('363','31','固原'),('364','31','石嘴山'),('365','31','吴忠'),('366','32','乌鲁木齐'),('367','32','吐鲁番'),('368','32','阿克苏'),('369','32','阿拉尔'),('370','32','巴音郭楞蒙古自治州'),('371','32','博尔塔拉蒙古自治州'),('372','32','昌吉回族自治州'),('373','32','哈密'),('374','32','和田'),('375','32','喀什'),('376','32','克拉玛依'),('377','32','克孜勒苏柯尔克孜自治州'),('378','32','石河子'),('379','32','图木舒克'),('380','32','五家渠'),('381','32','伊犁哈萨克自治州'),('382','33','香港'),('383','34','澳门');/* MySQLReback Separation */
 /* 创建表结构`boc_question`*/
 DROP TABLE IF EXISTS`boc_question`;/* MySQLReback Separation */CREATE TABLE `boc_question` (
  `id` int(11) NOT NULL auto_increment COMMENT '唯一编号',
  `sort_id` int(11) default '1' COMMENT '排序编号',
  `type_id` int(11) default NULL COMMENT '类型',
  `title` varchar(255) default NULL COMMENT '标题',
  `intro` varchar(1000) default NULL COMMENT '简介',
  `tag` varchar(255) default NULL COMMENT '标签',
  `content` mediumtext COMMENT '内容',
  `timeline` int(11) default NULL COMMENT '发布/修改时间',
  `expire` int(11) default NULL COMMENT '公告过期时间',
  `author` varchar(50) default NULL COMMENT '消息作者',
  `author_url` varchar(255) default NULL COMMENT '作者链接',
  `source` varchar(50) default NULL COMMENT '消息来源',
  `source_url` varchar(255) default NULL COMMENT '来源链接',
  `click` int(11) default '0' COMMENT '浏览次数',
  `show` tinyint(4) default '1' COMMENT '显隐状态',
  `recommend` tinyint(4) default '0' COMMENT '推荐到分类门户的页面显示',
  `photo` varchar(255) default NULL COMMENT '相关图片',
  `thumb` varchar(255) default NULL COMMENT '图片缩略图',
  `file` varchar(255) default NULL COMMENT '相关文件',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_record`*/
 DROP TABLE IF EXISTS`boc_record`;/* MySQLReback Separation */CREATE TABLE `boc_record` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `type_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `url` varchar(255) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `recommend` tinyint(4) default '0',
  `show` tinyint(4) default '1',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_recruit`*/
 DROP TABLE IF EXISTS`boc_recruit`;/* MySQLReback Separation */CREATE TABLE `boc_recruit` (
  `id` int(11) NOT NULL auto_increment COMMENT '唯一编号',
  `sort_id` int(11) default '1' COMMENT '排序编号',
  `type_id` int(11) default NULL COMMENT '类型',
  `title` varchar(255) default NULL COMMENT '标题',
  `intro` mediumtext COMMENT '简介',
  `content` mediumtext COMMENT '内容',
  `contents` mediumtext,
  `timeline` int(11) default NULL COMMENT '发布/修改时间',
  `expire` int(11) default NULL COMMENT '公告过期时间',
  `click` int(11) default '0' COMMENT '浏览次数',
  `show` tinyint(4) default '1' COMMENT '显隐状态',
  `recommend` tinyint(4) default '0' COMMENT '推荐到分类门户的页面显示',
  `color` tinyint(4) default '0' COMMENT '突显状态/颜色',
  `photo` varchar(255) default NULL COMMENT '相关图片',
  `thumb` varchar(255) default NULL COMMENT '图片缩略图',
  `file` varchar(255) default NULL COMMENT '相关文件',
  `ex1` varchar(255) default '' COMMENT '其他标签（预留）',
  `ex2` varchar(255) default '',
  `ex3` varchar(255) default '',
  `ex4` varchar(255) default '',
  `ex5` varchar(255) default '',
  `ex6` varchar(255) default NULL,
  `country` varchar(50) default NULL,
  `province` varchar(50) default NULL,
  `city` varchar(50) default NULL,
  `county` varchar(50) default NULL,
  `place` varchar(255) default NULL,
  `title_require` varchar(50) default NULL COMMENT '职称要求',
  `amount` int(11) default NULL,
  `department` varchar(50) default NULL,
  `gender` varchar(10) default NULL,
  `age` smallint(6) default NULL,
  `age_max` smallint(6) default NULL,
  `edu` varchar(50) default NULL,
  `major` varchar(50) default NULL,
  `experience` varchar(50) default NULL,
  `requirement` text,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_recruit_apply`*/
 DROP TABLE IF EXISTS`boc_recruit_apply`;/* MySQLReback Separation */CREATE TABLE `boc_recruit_apply` (
  `id` int(11) NOT NULL auto_increment COMMENT '唯一编号',
  `sort_id` int(11) default '1' COMMENT '排序编号',
  `type_id` int(11) default NULL COMMENT '类型',
  `recruit_id` int(11) default NULL,
  `title` varchar(255) default NULL COMMENT '应聘标题',
  `intro` varchar(1000) default NULL COMMENT '简介',
  `content` mediumtext COMMENT '内容',
  `timeline` int(11) default NULL COMMENT '发布/修改时间',
  `expire` int(11) default NULL COMMENT '公告过期时间',
  `click` int(11) default '0' COMMENT '浏览次数',
  `show` tinyint(4) default '1' COMMENT '显隐状态',
  `recommend` tinyint(4) default '0' COMMENT '推荐到分类门户的页面显示',
  `color` tinyint(4) default '0' COMMENT '突显状态/颜色',
  `audit` tinyint(4) default NULL COMMENT '审核状态',
  `photo` varchar(255) default NULL COMMENT '相关图片',
  `thumb` varchar(255) default NULL COMMENT '图片缩略图',
  `file` varchar(255) default NULL COMMENT '相关文件',
  `ex1` varchar(255) default '' COMMENT '其他标签（预留）',
  `ex2` varchar(255) default '',
  `ex3` varchar(255) default '',
  `ex4` varchar(255) default '',
  `ex5` varchar(255) default '',
  `ex6` varchar(255) default NULL,
  `country` varchar(50) default NULL,
  `province` varchar(50) default NULL,
  `city` varchar(50) default NULL,
  `county` varchar(50) default NULL,
  `place` varchar(255) default NULL,
  `department` varchar(50) default NULL COMMENT '部门',
  `name` varchar(50) default NULL,
  `gender` varchar(10) default NULL,
  `marriage` varchar(50) default NULL,
  `email` varchar(100) default NULL,
  `tel` varchar(100) default NULL,
  `mobile` varchar(100) default NULL,
  `qq` varchar(100) default NULL,
  `msn` varchar(100) default NULL,
  `wangwang` varchar(100) default NULL,
  `nation` varchar(50) default NULL COMMENT '民族',
  `birthday` varchar(20) default NULL,
  `politic` varchar(50) default NULL COMMENT '政治面貌',
  `birthplace` varchar(50) default NULL COMMENT '籍贯',
  `school` varchar(100) default NULL,
  `major` varchar(50) default NULL COMMENT '专业',
  `graduation` varchar(20) default NULL COMMENT '毕业时间',
  `language` varchar(50) default NULL COMMENT '外语水平',
  `position` varchar(100) default NULL COMMENT '应聘职位',
  `age` smallint(6) default NULL,
  `edu` varchar(50) default NULL,
  `experience` varchar(50) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_recruit_type`*/
 DROP TABLE IF EXISTS`boc_recruit_type`;/* MySQLReback Separation */CREATE TABLE `boc_recruit_type` (
  `id` int(11) NOT NULL auto_increment,
  `type_id` int(11) default '1',
  `parent_id` int(11) default NULL,
  `depth` int(11) default '0',
  `path` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `intro` varchar(1000) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `order_id` int(11) default '0',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `path_index` (`path`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_seo`*/
 DROP TABLE IF EXISTS`boc_seo`;/* MySQLReback Separation */CREATE TABLE `boc_seo` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `type_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `ktitle` varchar(1000) default NULL,
  `intro` text,
  `content` text,
  `url` varchar(255) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `recommend` tinyint(4) default '0',
  `show` tinyint(4) default '1',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_showcase`*/
 DROP TABLE IF EXISTS`boc_showcase`;/* MySQLReback Separation */CREATE TABLE `boc_showcase` (
  `id` int(11) NOT NULL auto_increment COMMENT '唯一编号',
  `sort_id` int(11) default '1' COMMENT '排序编号',
  `type_id` int(11) default NULL COMMENT '类型',
  `title` varchar(255) default NULL COMMENT '标题',
  `intro` varchar(1000) default NULL COMMENT '简介',
  `content` mediumtext COMMENT '内容',
  `timeline` int(11) default NULL COMMENT '发布/修改时间',
  `expire` int(11) default NULL COMMENT '公告过期时间',
  `author` varchar(50) default NULL COMMENT '消息作者',
  `author_url` varchar(255) default NULL COMMENT '作者链接',
  `source` varchar(50) default NULL COMMENT '消息来源',
  `source_url` varchar(255) default NULL COMMENT '来源链接',
  `click` int(11) default '0' COMMENT '浏览次数',
  `show` tinyint(4) default '1' COMMENT '显隐状态',
  `recommend` tinyint(4) default '0' COMMENT '推荐到分类门户的页面显示',
  `homepage` tinyint(4) default '0' COMMENT '推荐到首页显示',
  `color` tinyint(4) default '0' COMMENT '突显状态/颜色',
  `photo` varchar(255) default NULL COMMENT '相关图片',
  `thumb` varchar(255) default NULL COMMENT '图片缩略图',
  `file` varchar(255) default NULL COMMENT '相关文件',
  `ex1` varchar(255) default '' COMMENT '其他标签（预留）',
  `ex2` varchar(255) default '',
  `ex3` varchar(255) default '',
  `ex4` varchar(255) default '',
  `ex5` varchar(255) default '',
  `ex6` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_single`*/
 DROP TABLE IF EXISTS`boc_single`;/* MySQLReback Separation */CREATE TABLE `boc_single` (
  `id` int(11) NOT NULL auto_increment COMMENT '唯一编号',
  `type_id` int(11) default NULL COMMENT '类型',
  `title` varchar(255) default NULL COMMENT '标题',
  `intro` varchar(1000) default NULL COMMENT '简介',
  `content` mediumtext COMMENT '内容',
  `content2` mediumtext COMMENT '内容2',
  `content3` mediumtext COMMENT '内容3',
  `content4` mediumtext COMMENT '内容4',
  `content5` mediumtext COMMENT '内容5',
  `content6` mediumtext COMMENT '内容6',
  `timeline` int(11) default NULL COMMENT '发布/修改时间',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 插入数据`boc_single`*/
 INSERT INTO`boc_single`VALUES('1','','','','','','','','','','');/* MySQLReback Separation */
 /* 创建表结构`boc_store`*/
 DROP TABLE IF EXISTS`boc_store`;/* MySQLReback Separation */CREATE TABLE `boc_store` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `type_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `url` varchar(255) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `show` tinyint(4) default '1',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_users`*/
 DROP TABLE IF EXISTS`boc_users`;/* MySQLReback Separation */CREATE TABLE `boc_users` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `type_id` int(11) default NULL,
  `username` varchar(50) default NULL,
  `password` varchar(50) default NULL,
  `title` varchar(100) default NULL,
  `click` int(11) default NULL,
  `tel` varchar(50) default NULL,
  `email` varchar(100) default NULL,
  `addr` varchar(100) default NULL,
  `content` text,
  `audit` tinyint(4) default NULL,
  `solve` tinyint(4) default '0' COMMENT '已解决？',
  `show` tinyint(4) default NULL,
  `timeline` int(11) default NULL,
  `gender` varchar(255) default NULL,
  `birth` varchar(255) default NULL,
  `company` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */
 /* 创建表结构`boc_video`*/
 DROP TABLE IF EXISTS`boc_video`;/* MySQLReback Separation */CREATE TABLE `boc_video` (
  `id` int(11) NOT NULL auto_increment,
  `sort_id` int(11) default NULL,
  `type_id` int(11) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `url` varchar(255) default NULL,
  `video` varchar(255) default NULL,
  `photo` varchar(255) default NULL,
  `thumb` varchar(255) default NULL,
  `show` tinyint(4) default '1',
  `timeline` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;/* MySQLReback Separation */